<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '4b76c6e5c5178aaa28563d94b8c55d1a',
      'native_key' => 'versionx',
      'filename' => 'modNamespace/abe679d9028f9943a0c07ba4f0d85cf2.vehicle',
      'namespace' => 'versionx',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'a60f592cfbeb30d133a41361651af63c',
      'native_key' => 1,
      'filename' => 'modPlugin/20454bc3f9c3939053c5399c76b5c394.vehicle',
      'namespace' => 'versionx',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'be9ca18fe413ae8c20b2735c010a6fdf',
      'native_key' => 'versionx.versionx',
      'filename' => 'modMenu/85408c42b8b44b7467c77b46a739fe2a.vehicle',
      'namespace' => 'versionx',
    ),
  ),
);